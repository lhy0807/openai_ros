*Based on the [openai_ros](https://bitbucket.org/theconstructcore/openai_ros/src/version2/) package whose [Wiki](http://wiki.ros.org/openai_ros) page provides the general documentation.
