# TODO:
# 1. Add turtlebot2 and instructions (including sick).
# 2. Add jackal (both sim and real)
# 3. Add HSR (both sim and real)

# Tentabot-DRL: Robot Navigation in Dynamic Environments using Deep Reinforcement Learning with Pre-sampled Trajectory Value Observations
![teaser](videos/tentabot_drl_training_static_0.gif) ![teaser](videos/tentabot_drl_training_static_1.gif) ![teaser](videos/tentabot_drl_training_dynamic_0.gif) ![teaser](videos/tentabot_drl_training_dynamic_1.gif)

# Tentabot-Heuristic: Reactive Navigation Framework for Mobile Robots by Heuristically Evaluated Pre-sampled Trajectories (Tentacles)
[![teaser](videos/tentabot_heuristic_firefly_cylinders0.gif)](https://youtu.be/5vZSEuWUXe4) [![teaser](videos/tentabot_heuristic_firefly_forest1.gif)](https://youtu.be/5vZSEuWUXe4)

### 1. Citation
```
@article{akmandor2021reactive,
  title={Reactive navigation framework for mobile robots by heuristically evaluated pre-sampled trajectories},
  author={Akmandor, Ne{\c{s}}et {\"U}nver and Padir, Ta{\c{s}}kin},
  journal={International Journal of Robotic Computing},
  volume={3},
  number={1},
  pages={47--68},
  year={2021}
}
```
```
@inproceedings{akmandor20203d,
  title={A 3d reactive navigation algorithm for mobile robots by using tentacle-based sampling},
  author={Akmandor, Ne{\c{s}}et {\"U}nver and Padir, Ta{\c{s}}kin},
  booktitle={2020 Fourth IEEE International Conference on Robotic Computing (IRC)},
  pages={9--16},
  year={2020},
  organization={IEEE}
}
```

### 2. Related Papers
* Akmandor, N. Ü. and Padır, T., "**Reactive navigation framework for mobile robots by heuristically evaluated pre-sampled trajectories**," International Journal of Robotic Computing 3.1 (2021): 47-68, [[DOI:10.35708/RC1870-126265]](https://b5589c9e-f1e3-4455-9929-0d78781398a4.filesusr.com/ugd/e49175_ccc84165293e42f79a1d4ad98260e8b9.pdf). [[arXiv:10.35708/RC1870-126265]](https://arxiv.org/abs/2105.08145)
* Akmandor, N. Ü. and Padır, T., "**A 3D Reactive Navigation Algorithm for Mobile Robots by Using Tentacle-Based Sampling**," 2020 Fourth IEEE International Conference on Robotic Computing (IRC), Taichung, Taiwan, 2020, pp. 9-16, [[DOI:10.1109/IRC.2020.00009]](https://doi.org/10.1109/IRC.2020.00009). [[arXiv:2001.09199]](https://arxiv.org/abs/2001.09199).
* Von Hundelshausen, Felix, et al. "**Driving with tentacles: Integral structures for sensing and motion**." Journal of Field Robotics 25.9 (2008): 640-673, [[DOI:10.1002/rob.20256]](https://doi.org/10.1002/rob.20256).

### 2. Videos

* [[IRC 2020 - supplementary video]](https://www.youtube.com/watch?v=5vZSEuWUXe4&t)
* [[IRC 2020 - presentation]](https://youtu.be/Y5FCiJPXmlo)

### 3 Installation

The system has been tested with 20.04 (ROS Noetic).

Follow the tutorials to
- [install ROS](http://wiki.ros.org/ROS/Installation) based on the Ubuntu version.
- [set up catkin workspace](http://wiki.ros.org/ROS/Tutorials/InstallingandConfiguringROSEnvironment).

#### Tentabot depends on the following libraries/packages:

- [flexible-collision-library/fcl](https://github.com/flexible-collision-library/fcl)
- [libccd](https://github.com/danfis/libccd)

- [rotors_simulator](https://github.com/ethz-asl/rotors_simulator.git)
- [turtlebot3](https://github.com/RIVeR-Lab/turtlebot3/tree/noetic-akmandor) - 'noetic-akmandor' branch
- [LMS1xx](https://github.com/RIVeR-Lab/LMS1xx/tree/noetic-akmandor) - 'noetic-akmandor' branch
- [geometry2](https://github.com/RIVeR-Lab/geometry2/tree/noetic-akmandor) - 'noetic-akmandor' branch
- [catkin-simple](https://github.com/catkin/catkin_simple)
- [forest_gen](https://github.com/ethz-asl/forest_gen)
- [mav_comm](https://github.com/ethz-asl/mav_comm)
- [octomap_rviz_plugins](https://github.com/OctoMap/octomap_rviz_plugins)
- [pedsim_ros](https://github.com/srl-freiburg/pedsim_ros.git)
- [openai-ros](https://github.com/RIVeR-Lab/openai_ros)

- [stable-baselines3](https://stable-baselines3.readthedocs.io/en/master/guide/install.html#stable-release)
- [libsuitesparse](https://packages.debian.org/sid/libsuitesparse-dev)
- [libnlopt-dev](https://nlopt.readthedocs.io/en/latest/NLopt_Installation/)

- [GitPython](https://gitpython.readthedocs.io/en/stable/)
- [squaternion](https://github.com/MomsFriendlyRobotCompany/squaternion)

- [strech_ros](https://github.com/hello-robot/stretch_ros.git)
- [realsense-gazebo-plugin](https://github.com/pal-robotics/realsense_gazebo_plugin.git)
- [teleop_tools](https://github.com/ros-teleop/teleop_tools)  -  kinetic branch
- [joystick_drivers](https://github.com/ros-drivers/joystick_drivers.git)

- [jackal](https://github.com/jackal/jackal.git)
- [husky](https://github.com/husky/husky.git)

- [navrep](https://github.com/ethz-asl/navrep.git) (for Rings representation of LiDAR) python setup.py install
#### 3.1 Clone the tentabot repository into the src folder of your catkin workspace, and change into the tentabot directory
```
git clone https://github.com/RIVeR-Lab/tentabot.git
cd tentabot
```
#### 3.2 Run the bash script to automate installing all dependencies

##### 3.2.1 Note: This script requires superuser and makes system changes. Review the script before running.
```
chmod +x install_tentabot.sh
sudo ./install_tentabot.sh
```

#### 3.3 Source the workspace, after successfully built:
```
source devel/setup.bash
```

### 4. Simulation examples
Tentabot features out of the box simulation support for certain robots. You can view the status of this support here:

| robot / model| manufacturer |   garden      | rviz | map_utility | heuristic | drl| notes|
|:------|:--------------------|:--------------|:-----|:------------|:----------|:--|:------|
|Turtlebot 3 Burger|Robotis| :heavy_check_mark:|:heavy_check_mark:|:heavy_check_mark:|:heavy_check_mark:| :heavy_check_mark:| Referred to as turtlebot|
|Firefly | AscTec | :heavy_check_mark: |  :heavy_check_mark:  |:heavy_check_mark:|  :heavy_check_mark: |:heavy_check_mark:| Uses mav_garden not mobile_garden, referred to as firefly|
|ROSbot |   Husarion   |:heavy_check_mark: |  :heavy_check_mark: | :heavy_check_mark:| :heavy_check_mark: |:heavy_check_mark:| |
|Stretch |   hello robot   |:heavy_check_mark: |  :heavy_check_mark: | :heavy_check_mark:| :heavy_check_mark: |:heavy_check_mark:| |
|Jackal        | Clearpath    |        :heavy_check_mark:    |  ❌  |     ❌      |     ❌    |  ❌ | referred to as jackal |
#### 4.1 Tentabot-DRL:
In separate terminal windows:

##### 4.1.1 Start Gazebo simulation:
```
roslaunch tentabot mobile_garden.launch robot:=turtlebot
```
| argument   |    default    | example argument | description |
| :----------|:--------------|:----------------| :-----------|
| robot      | turtlebot    | ROSbot, stretch  | what robot to simulate|

##### 4.1.2 Start Rviz for visualization:
```
roslaunch tentabot tentabot_drl_rviz.launch
```

##### 4.1.3 Start map utility:
```
roslaunch tentabot map_utility_server.launch robot:=turtlebot ns:=/turtlebot0
```
| argument   |    default    | example argument | description |
| :----------|:--------------|:----------------| :-----------|
| robot      | turtlebot    | ROSbot, stretch  | robot model to start the map utility server for|
| ns   | $(arg robot)0         | "turtlebot0", "ROSbot1"   | namespace to run the mapping utility in|


##### 4.1.4 Start Tentabot-DRL service:
```
roslaunch tentabot tentabot_drl_service.launch
```

##### 4.1.5 Start training:
```
roslaunch tentabot tentabot_drl_training.launch
```
OR

##### 4.1.5 Start testing:
```
roslaunch tentabot tentabot_drl_testing.launch
```

#### 4.2 Tentabot-Heuristic:

##### Example 1:
```
roslaunch tentabot tentabot_heuristic_firefly_cylinders.launch
```

##### Example 2:
```
roslaunch tentabot tentabot_heuristic_firefly_forest.launch
```

##### Example 3:
```
roslaunch tentabot tentabot_heuristic_turtlebot3.launch
```
#### 4.3 Tentabot-DRL on Stretch:
```
roslaunch tentabot mobile_garden_stretch.launch
roslaunch tentabot tentabot_drl_rviz_stretch.launch
roslaunch tentabot map_utility_server.launch robot:=stretch
roslaunch tentabot tentabot_drl_service_stretch.launch
roslaunch tentabot tentabot_drl_training_stretch.launch
```

### 5. Real robot examples

#### 5.1 Turtlebot2: Bring-up the robot:
```
roslaunch tentabot turtlebot2_bringup.launch
```

#### 5.2 Turtlebot2: Start Rviz for visualization:
```
roslaunch tentabot turtlebot2_rviz.launch
```

#### 5.3 Turtlebot2: Start camera:
```
roslaunch tentabot turtlebot2_camera.launch
```

#### 5.4 Turtlebot2: Start laser-scan:
```
roslaunch tentabot sick_lms_1xx.launch
```

#### 5.5 Turtlebot2: Start gmapping:
```
roslaunch tentabot gmapping_sick.launch
```

#### 5.6 Turtlebot2: Start map utility:
```
roslaunch tentabot map_utility_server_turtlebot2.launch
```

##### 5.7 Start Tentabot-DRL service:
```
roslaunch tentabot tentabot_drl_service_turtlebot2.launch
```

##### 5.8 Start training:
```
roslaunch tentabot tentabot_drl_training.launch #Set config file to training_real
```
OR

##### 5.8 Start testing:
```
roslaunch tentabot tentabot_drl_testing.launch #Set config file to testing_real
```

#### (Optional) Turtlebot2: Start teleop:
```
roslaunch turtlebot_teleop keyboard_teleop.launch
```

### 6. Credentials
Tentabot was developed at the [RIVeR Lab, Northeastern University](http://robot.neu.edu/).
